module com.gdtm {
    requires transitive javafx.controls;
    requires javafx.fxml;

    opens com.gdtm to javafx.fxml;
    exports com.gdtm;
}
