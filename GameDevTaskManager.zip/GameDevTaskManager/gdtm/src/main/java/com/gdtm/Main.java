package com.gdtm;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

    private final ObservableList<Task> taskList = FXCollections.observableArrayList();
    private ListView<Task> taskListView;
    private TextField titleField;
    private TextArea descriptionArea;
    private ProgressBar progressBar;


    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("GDTM - Game Dev Task Manager");

        primaryStage.getIcons().add(new Image("file:src/main/resources/Icon_HQ.png"));
        titleField = new TextField();
        titleField.setPromptText("Título da Tarefa");

        descriptionArea = new TextArea();
        descriptionArea.setPromptText("Descrição da Tarefa");
        descriptionArea.setWrapText(true);

        Button addButton = new Button("Adicionar Tarefa");
        Button editButton = new Button("Editar Tarefa");
        Button deleteButton = new Button("Excluir Tarefa");
        Button completeButton = new Button("Marcar como Concluído");
        Button saveButton = new Button("Salvar");
        Button openButton = new Button("Abrir");
        

        taskListView = new ListView<>(taskList);
        taskListView.setPrefHeight(200);
        taskListView.setCellFactory(listView -> new ListCell<Task>() {
            @Override
            protected void updateItem(Task task, boolean empty) {
                super.updateItem(task, empty);
                if (empty || task == null) {
                    setText(null);
                    setStyle("");
                } else {
                    setText(task.toString()); // Já retorna formatado com o simbolo
                    setStyle(task.getStyle()); // Cor verde quando concluído
                }
            }
        });
        

        

        addButton.setOnAction(e -> addTask());
        editButton.setOnAction(e -> editTask());
        deleteButton.setOnAction(e -> deleteTask());
        completeButton.setOnAction(e -> completeTask());
        saveButton.setOnAction(e -> saveTasksToFile());
        openButton.setOnAction(e -> loadTasksFromFile());

        HBox buttonLayout = new HBox(10, addButton, editButton, deleteButton, completeButton);
        HBox fileButtonLayout = new HBox(10, saveButton, openButton);

        progressBar = new ProgressBar(0); // Começa vazia
        progressBar.setPrefWidth(400); // Define um tamanho pra ela

        VBox layout = new VBox(10, titleField, descriptionArea, buttonLayout, taskListView, fileButtonLayout, progressBar);
        layout.setPadding(new Insets(20));

        Scene scene = new Scene(layout, 500, 550); // Criando a cena com o layout

        scene.setOnKeyPressed(event -> {
            switch (event.getCode()) {
                case S:
                    saveTasksToFile();
                    break;
                case O:
                    loadTasksFromFile(); 
                    break;
                case DELETE:
                    deleteTask(); 
                    break;
                case N:
                    if (event.isControlDown()) addTask();
                    break;
                case D:
                    if (event.isControlDown()) completeTask();
                    break;
                case ENTER:
                    editTask();
                    break;
                case E:
                    if (event.isControlDown()) editTask();
                    break;
            }
        });

        primaryStage.setScene(scene);
        primaryStage.show();
        
    }

    private void updateProgressBar() {
        if (taskList.isEmpty()) {
            progressBar.setProgress(0); // Se não houver tarefas, barra vazia
            return;
        }

        long completedTasks = taskList.stream().filter(Task::isCompleted).count();
        double progress = (double) completedTasks / taskList.size();
        progressBar.setProgress(progress);
    }


    private void addTask() {
        String title = titleField.getText().trim();
        String description = descriptionArea.getText().trim();

        if (title.isEmpty() || description.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Entrada inválida", "Preencha título e descrição.");
            return;
        }

        if (taskExists(title)) {
            showAlert(Alert.AlertType.WARNING, "Tarefa Duplicada", "Já existe uma tarefa com este título.");
            return;
        }

        taskList.add(new Task(title, description));
        clearFields();
        updateProgressBar();
    }

    private void editTask() {
        Task selectedTask = taskListView.getSelectionModel().getSelectedItem();
        if (selectedTask == null) {
            showAlert(Alert.AlertType.WARNING, "Nenhuma Tarefa Selecionada", "Selecione uma tarefa para editar.");
            return;
        }

        String newTitle = titleField.getText().trim();
        String newDescription = descriptionArea.getText().trim();

        if (newTitle.isEmpty() && newDescription.isEmpty()) {
            titleField.appendText(selectedTask.getTitle());
            descriptionArea.appendText(selectedTask.getDescription());
            return;
        }

        if (newTitle.isEmpty() || newDescription.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Entrada inválida", "Preencha título e descrição.");
            return;
        }

        if (!selectedTask.getTitle().equalsIgnoreCase(newTitle) && taskExists(newTitle)) {
            showAlert(Alert.AlertType.WARNING, "Tarefa Duplicada", "Já existe uma tarefa com este título.");
            return;
        }

        if (confirmAction("Confirmar Edição", "Tem certeza que deseja editar esta tarefa?")) {
            selectedTask.setTitle(newTitle);
            selectedTask.setDescription(newDescription);
            taskListView.refresh();
            clearFields();
        }
    }

    private void deleteTask() {
        Task selectedTask = taskListView.getSelectionModel().getSelectedItem();
        if (selectedTask == null) {
            showAlert(Alert.AlertType.WARNING, "Nenhuma Tarefa Selecionada", "Selecione uma tarefa para excluir.");
            return;
        }

        if (confirmAction("Confirmar Exclusão", "Tem certeza que deseja excluir esta tarefa?")) {
            taskList.remove(selectedTask);
            clearFields();
            updateProgressBar();
        }
    }

    private void completeTask() {
        Task selectedTask = taskListView.getSelectionModel().getSelectedItem();
        if (selectedTask == null) {
            showAlert(Alert.AlertType.WARNING, "Nenhuma Tarefa Selecionada", "Selecione uma tarefa para marcar como concluída.");
            return;
        }
        selectedTask.setCompleted(true);
        taskListView.refresh();
        updateProgressBar();
    }

    private void saveTasksToFile() {
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Salvar Tarefas");
    fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Save Files (*.gdtm)", "*.gdtm"));
    
    File file = fileChooser.showSaveDialog(null);
    
    if (file != null) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(new ArrayList<>(taskList));
            System.out.println("Tarefas salvas em: " + file.getAbsolutePath()); // Debug
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erro ao salvar", "Não foi possível salvar as tarefas.");
        }
    }
}


private void loadTasksFromFile() {
    FileChooser fileChooser = new FileChooser();
    fileChooser.setTitle("Abrir Tarefas");
    fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Save Files (*.gdtm)", "*.gdtm"));
    
    File file = fileChooser.showOpenDialog(null);
    
    if (file != null) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                List<?> rawList = (List<?>) obj;
                List<Task> safeList = new ArrayList<>();
        
                for (Object item : rawList) {
                    if (item instanceof Task) {
                        safeList.add((Task) item);
                    }
                }
                taskList.setAll(safeList);
                System.out.println("Tarefas carregadas de: " + file.getAbsolutePath()); // Debug
            } else {
                showAlert(Alert.AlertType.ERROR, "Erro ao carregar", "Formato de arquivo inválido.");
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erro ao carregar", "Não foi possível carregar as tarefas.");
        }
        updateProgressBar();
    }
}


    private boolean taskExists(String title) {
        return taskList.stream().anyMatch(task -> task.getTitle().equalsIgnoreCase(title));
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type, content, ButtonType.OK);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    private boolean confirmAction(String title, String content) {
        return new Alert(Alert.AlertType.CONFIRMATION, content, ButtonType.OK, ButtonType.CANCEL)
                .showAndWait()
                .orElse(ButtonType.CANCEL) == ButtonType.OK;
    }

    private void clearFields() {
        titleField.clear();
        descriptionArea.clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
